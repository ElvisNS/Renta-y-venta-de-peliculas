﻿using Microsoft.Extensions.Logging;
using Renta_y_venta_de_peliculas.DAL.Context;
using Renta_y_venta_de_peliculas.DAL.Entities;
using Renta_y_venta_de_peliculas.DAL.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;

namespace Renta_y_venta_de_peliculas.DAL.Repositories
{
    public class PeliculaRepository : Core.RepositoryBase<Pelicula>, IPeliculaRepository
    {
        private readonly RYPContext rYPContext;
        private readonly ILogger<PeliculaRepository> ilogger;

        public PeliculaRepository(RYPContext rYPContext, ILogger<PeliculaRepository> ilogger): base(rYPContext)
        {
            this.rYPContext = rYPContext;
            this.ilogger = ilogger;
        }
        public override List<Pelicula> GetEntities()
        {
            return this.rYPContext.Peliculas.Where(de => !de.Deleted).OrderByDescending(cd=> cd.Create_date).ToList();
        }

        public override Pelicula GetEntity(int id)
        {
            return base.GetEntity(id);
        }
        public override void Remove(Pelicula entity)
        {
            base.Remove(entity);
            base.SaveChanges();
        }
    }
}
